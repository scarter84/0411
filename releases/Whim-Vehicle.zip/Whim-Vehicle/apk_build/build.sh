#!/usr/bin/env bash
set -euo pipefail

BUILD="/home/tommymunro/vaults/WHIM/vehicle/apk_build"
SDK="/home/tommymunro/Android/Sdk"
BT="$SDK/build-tools/33.0.3"
PLATFORM="$SDK/platforms/android-33/android.jar"
OUT="$BUILD/out"

GREEN='\033[0;32m'
NC='\033[0m'
info() { echo -e "${GREEN}[BUILD]${NC} $*"; }

rm -rf "$OUT"
mkdir -p "$OUT/gen" "$OUT/classes" "$OUT/apk"

info "Step 1: Compile resources with aapt2..."
# Compile each resource directory
for resdir in "$BUILD"/res/mipmap-*; do
    "$BT/aapt2" compile --dir "$resdir" -o "$OUT/compiled_res/" 2>&1 || true
done

# If aapt2 compile --dir doesn't work well, compile individual files
if [ ! -d "$OUT/compiled_res" ] || [ -z "$(ls -A "$OUT/compiled_res" 2>/dev/null)" ]; then
    mkdir -p "$OUT/compiled_res"
    find "$BUILD/res" -name "*.png" | while read f; do
        "$BT/aapt2" compile "$f" -o "$OUT/compiled_res/" 2>&1
    done
fi

info "Step 2: Link resources..."
"$BT/aapt2" link \
    -o "$OUT/apk/whim_v_unsigned.apk" \
    -I "$PLATFORM" \
    --manifest "$BUILD/AndroidManifest.xml" \
    --java "$OUT/gen" \
    --auto-add-overlay \
    "$OUT"/compiled_res/*.flat 2>&1

info "Step 3: Compile Java..."
javac -source 1.8 -target 1.8 \
    -classpath "$PLATFORM" \
    -d "$OUT/classes" \
    "$OUT/gen/com/whim/v/R.java" \
    "$BUILD/java/com/whim/v/MainActivity.java" 2>&1

info "Step 4: Create DEX..."
"$BT/d8" --output "$OUT/apk/" "$OUT"/classes/com/whim/v/*.class 2>&1

info "Step 5: Add DEX to APK..."
cd "$OUT/apk"
# Add classes.dex directly into the aapt2-linked APK (preserves resources.arsc alignment)
cp whim_v_unsigned.apk whim_v_with_dex.apk
zip -j whim_v_with_dex.apk classes.dex >/dev/null 2>&1

info "Step 6: Zipalign..."
"$BT/zipalign" -p -f 4 "$OUT/apk/whim_v_with_dex.apk" "$OUT/apk/whim_v_aligned.apk" 2>&1

info "Step 7: Generate signing key..."
if [ ! -f "$BUILD/whim_v.keystore" ]; then
    keytool -genkeypair -v \
        -keystore "$BUILD/whim_v.keystore" \
        -alias whimv \
        -keyalg RSA -keysize 2048 -validity 10000 \
        -storepass whimv123 -keypass whimv123 \
        -dname "CN=Whim.V, O=Whim, C=US" 2>&1
fi

info "Step 8: Sign APK..."
"$BT/apksigner" sign \
    --ks "$BUILD/whim_v.keystore" \
    --ks-key-alias whimv \
    --ks-pass pass:whimv123 \
    --key-pass pass:whimv123 \
    --out "$OUT/whim_v.apk" \
    "$OUT/apk/whim_v_aligned.apk" 2>&1

info "Done! APK: $OUT/whim_v.apk"
ls -lh "$OUT/whim_v.apk"
