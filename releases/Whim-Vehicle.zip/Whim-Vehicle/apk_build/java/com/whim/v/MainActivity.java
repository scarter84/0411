package com.whim.v;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.RenderProcessGoneDetail;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.content.Context;
import android.content.SharedPreferences;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {

    private WebView webView;
    private static final String WHIM_V_URL_EMU = "http://10.0.2.2:8099";
    private static final String WHIM_V_URL_TS  = "http://100.69.17.20:8099";
    private static final String WHIM_V_URL_LAN = "http://192.168.1.231:8099";
    private static final String[] WHIM_V_URLS = {
        WHIM_V_URL_EMU, WHIM_V_URL_TS, WHIM_V_URL_LAN
    };
    private static final long URL_TIMEOUT_MS = 6000;
    private static final long RECONNECT_INTERVAL_MS = 15000;
    private static final String PREFS_NAME = "whim_v_cache";
    private static final String PREF_CACHED_HTML = "cached_html";
    private static final String PREF_CACHED_URL = "cached_url";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean pageLoaded = false;
    private boolean serverConnected = false;
    private boolean appRunning = true;
    private String connectedUrl = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#141210"));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);


        root.addView(webView, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));

        setContentView(root);

        loadDashboard();
    }

    private int urlIndex = 0;

    private void loadDashboard() {
        urlIndex = 0;
        tryNextUrl();
    }

    private String fetchHtmlFromUrl(String urlStr) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(4000);
            conn.setReadTimeout(4000);
            int code = conn.getResponseCode();
            if (code == 200) {
                InputStream is = conn.getInputStream();
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = is.read(buf)) != -1) bos.write(buf, 0, n);
                is.close();
                conn.disconnect();
                return bos.toString("UTF-8");
            }
            conn.disconnect();
        } catch (Exception e) { }
        return null;
    }

    private void cacheHtml(String html, String url) {
        try {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit().putString(PREF_CACHED_HTML, html).putString(PREF_CACHED_URL, url).apply();
        } catch (Exception e) { }
    }

    private String getCachedHtml() {
        try {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            return prefs.getString(PREF_CACHED_HTML, null);
        } catch (Exception e) { return null; }
    }

    private void tryNextUrl() {
        if (urlIndex >= WHIM_V_URLS.length) {
            loadOfflineOrError();
            return;
        }
        pageLoaded = false;
        final String url = WHIM_V_URLS[urlIndex];
        final int attemptIndex = urlIndex;

        handler.postDelayed(() -> {
            if (!pageLoaded && urlIndex == attemptIndex) {
                urlIndex++;
                webView.stopLoading();
                tryNextUrl();
            }
        }, URL_TIMEOUT_MS);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String finishedUrl) {
                if (finishedUrl != null && finishedUrl.startsWith("http")) {
                    pageLoaded = true;
                    serverConnected = true;
                    connectedUrl = finishedUrl;
                    new Thread(() -> {
                        String html = fetchHtmlFromUrl(finishedUrl);
                        if (html != null) cacheHtml(html, finishedUrl);
                    }).start();
                    startReconnectLoop();
                }
            }

            @Override
            public void onReceivedError(WebView view, int errorCode,
                    String description, String failingUrl) {
                if (pageLoaded) return;
                urlIndex++;
                handler.removeCallbacksAndMessages(null);
                view.post(() -> tryNextUrl());
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                FrameLayout parent = (FrameLayout) view.getParent();
                if (parent != null) parent.removeView(view);
                view.destroy();
                webView = new WebView(MainActivity.this);
                WebSettings s = webView.getSettings();
                s.setJavaScriptEnabled(true);
                s.setDomStorageEnabled(true);
                s.setCacheMode(WebSettings.LOAD_DEFAULT);
                s.setMediaPlaybackRequiresUserGesture(false);
                if (parent != null) parent.addView(webView);
                loadDashboard();
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl(url);
    }

    private void loadOfflineOrError() {
        serverConnected = false;
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        String cached = getCachedHtml();
        if (cached != null && cached.length() > 500) {
            webView.loadDataWithBaseURL("file:///android_asset/offline_dash.html",
                cached, "text/html", "UTF-8", null);
        } else {
            loadOfflineAsset();
        }
        startReconnectLoop();
    }

    private void loadOfflineAsset() {
        try {
            java.io.InputStream is = getAssets().open("offline_dash.html");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) != -1) bos.write(buf, 0, n);
            is.close();
            String html = bos.toString("UTF-8");
            webView.loadDataWithBaseURL("file:///android_asset/offline_dash.html",
                html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            webView.loadDataWithBaseURL("file:///android_asset/",
                "<html><body style='background:#141210;color:#e8793a;font-family:sans-serif;" +
                "display:flex;align-items:center;justify-content:center;height:100vh;" +
                "flex-direction:column'><h1>WHIM.V</h1><p style='color:#e8a83a'>Offline Mode</p>" +
                "<p style='color:#8a7a6a;font-size:12px'>Will auto-connect when dashboard is reachable</p>" +
                "</body></html>",
                "text/html", "UTF-8", null);
        }
    }

    private void startReconnectLoop() {
        handler.postDelayed(reconnectRunnable, RECONNECT_INTERVAL_MS);
    }

    private final Runnable reconnectRunnable = new Runnable() {
        @Override
        public void run() {
            if (!appRunning) return;
            new Thread(() -> {
                boolean wasConnected = serverConnected;
                for (String url : WHIM_V_URLS) {
                    String html = fetchHtmlFromUrl(url);
                    if (html != null) {
                        serverConnected = true;
                        cacheHtml(html, url);
                        if (!wasConnected) {
                            final String liveUrl = url;
                            runOnUiThread(() -> {
                                webView.setWebViewClient(new WebViewClient() {
                                    @Override
                                    public void onPageFinished(WebView view, String finishedUrl) {
                                        if (finishedUrl != null && finishedUrl.startsWith("http")) {
                                            pageLoaded = true;
                                            connectedUrl = finishedUrl;
                                        }
                                    }
                                });
                                webView.loadUrl(liveUrl);
                            });
                        }
                        break;
                    }
                }
                if (appRunning) {
                    handler.postDelayed(reconnectRunnable, RECONNECT_INTERVAL_MS);
                }
            }).start();
        }
    };

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        webView.evaluateJavascript(
            "(document.body && document.body.innerHTML.length > 0) ? 'ok' : 'empty'",
            value -> {
                if (value == null || value.contains("empty") || value.contains("null")) {
                    webView.reload();
                }
            }
        );
    }

    @Override
    protected void onPause() {
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        appRunning = false;
        handler.removeCallbacksAndMessages(null);
        webView.destroy();
        super.onDestroy();
    }
}
