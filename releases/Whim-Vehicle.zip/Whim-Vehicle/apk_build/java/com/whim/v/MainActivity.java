package com.whim.v;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.content.Context;

public class MainActivity extends Activity {

    private WebView webView;
    private static final String WHIM_V_URL_LAN = "http://192.168.1.231:8099";
    private static final String WHIM_V_URL_TS = "http://100.69.17.20:8099";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#141210"));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode,
                    String description, String failingUrl) {
                view.loadData(
                    "<html><body style='background:#141210;color:#f5e6d3;" +
                    "font-family:sans-serif;display:flex;align-items:center;" +
                    "justify-content:center;height:100vh;flex-direction:column;'>" +
                    "<h1 style='color:#e8793a;'>WHIM.V</h1>" +
                    "<p>Connecting to dashboard...</p>" +
                    "<p style='color:#8a7a6a;font-size:12px;'>Ensure Whim.V server is running on carraramint</p>" +
                    "<p style='color:#8a7a6a;font-size:12px;'>python3 whim_v.py --port 8099</p>" +
                    "<button onclick='location.reload()' style='margin-top:20px;" +
                    "background:#e8793a;color:#141210;border:none;padding:14px 28px;" +
                    "border-radius:6px;font-size:16px;font-weight:bold;'>Retry</button>" +
                    "</body></html>",
                    "text/html", "utf-8");
            }
        });

        webView.setWebChromeClient(new WebChromeClient());

        root.addView(webView, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));

        setContentView(root);

        loadDashboard();
    }

    private void loadDashboard() {
        webView.loadUrl(WHIM_V_URL_LAN);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onPause() {
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        webView.destroy();
        super.onDestroy();
    }
}
