Whim.V v1.3.0 — Vehicle Dashboard

Touch-optimized vertical dashboard for 13.6" displays and tablets.
GeoF geofence map, Doppler radar, AI chat, document viewer, system logs.
WhimLink BLE bridge for phone→dash pushpins and alerts.

Quick Start (server on your desktop):
  pip3 install flask requests
  python3 whim_v.py --port 8099

Android APK:
  Install whim_v.apk via ADB or sideload.
  The APK is a WebView wrapper that connects to the Whim.V Flask server
  via emulator bridge, Tailscale, or LAN — with offline caching.

Build from source:
  cd apk_build && bash build.sh

Requires: Python 3.10+, Flask, requests
