Whim.V v1.0.0 — Vehicle Dashboard

Quick Start:
  python3 whim_v.py --port 8099

Then open http://<your-ip>:8099 on your tablet or vehicle display.

To install the Android launcher APK:
  adb install whim_v.apk

To rebuild the APK from source:
  cd apk_build && bash build.sh

Requirements:
  - Python 3.10+, Flask, requests
  - LibreOffice (for document viewer)
  - Ollama (for AI chat)
  - Android SDK (to rebuild APK)

Features:
  - GeoF geofence map with collar tracking
  - NWS Doppler radar (KSRX, KLZK, KSGF)
  - LibreOffice headless document/spreadsheet viewer
  - AI chat via Ollama streaming
  - System status logs
