Whim Terminal v3.4.0 — Linux

Quick Start:
  1. cp config/openclaw.example.json ~/.openclaw/openclaw.json
  2. python3 app/openclaw_tkui.py

Optional AI models:
  bash scripts/setup_models.sh --status
  bash scripts/setup_models.sh --ollama
  bash scripts/setup_models.sh --xtts

Requirements: Python 3.10+, Tkinter, Pillow
  sudo apt install python3-tk python3-pil python3-pil.imagetk
  pip install qrcode websockets aiohttp mss

Full manual: docs/Whim_Manual.html
