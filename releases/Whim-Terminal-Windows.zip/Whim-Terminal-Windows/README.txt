Whim Terminal v3.4.0 — Windows 11

Quick Start:
  1. Run scripts\setup_windows.bat  (creates venv + installs deps)
  2. Run scripts\launch_whim.bat    (starts Whim Terminal)

Or manually:
  pip install -r app\requirements_windows.txt
  python app\whim_windows.py

Optional AI models:
  Install Ollama from https://ollama.com/download/windows
  ollama pull llama3.1:8b-16k

Requirements: Python 3.10+ from python.org (check "Add to PATH")

Full manual: docs\Whim_Manual.html
