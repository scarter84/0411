Whim.m v3.4.0 — Mobile Companion

Quick Start (server on your desktop/laptop):
  python3 whim_m_v2.1.py --port 8089

Then open http://<your-ip>:8089 on your phone's browser.

For native Android builds, see the mobile/ directory:
  - whim_m/         — Main Android app (Java)
  - whim_m_recorder — Voice recorder companion
  - whimtail/       — Tailscale mesh helper (Go)

Requires: Python 3.10+, Tailscale or local network access
