Whim Terminal — macOS

Quick Start:
  1. Install Python 3.10+ via Homebrew: brew install python-tk@3.12
  2. pip3 install Pillow qrcode websockets aiohttp mss
  3. cp config/openclaw.example.json ~/.openclaw/openclaw.json
  4. python3 app/openclaw_tkui.py

Optional AI models:
  brew install ollama
  ollama pull llama3.1:8b-16k

Full manual: docs/Whim_Manual.html
